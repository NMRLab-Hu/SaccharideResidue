#' Main function for saccharide residue matching and RMSE calculation
#'
#' This function performs matching between residue pairs from two sheets,
#' calculates RMSE values with dynamic permutation matching, and handles
#' special cases such as CH2 groups with chemical shift degeneracy.
#'
#' @param file_path Character string specifying the path to the Excel file
#' @param output_file Character string specifying the path for the output Excel file
#' @return A list containing detailed matching results and saves an Excel file with results
#' @export
SaccharideResidue <- function(file_path, output_file = NULL) {
  # Load required libraries
  if (!requireNamespace("readxl", quietly = TRUE)) {
    stop("Package 'readxl' is required but not installed")
  }
  if (!requireNamespace("openxlsx", quietly = TRUE)) {
    stop("Package 'openxlsx' is required but not installed")
  }
  if (!requireNamespace("dplyr", quietly = TRUE)) {
    stop("Package 'dplyr' is required but not installed")
  }
  if (!requireNamespace("combinat", quietly = TRUE)) {
    stop("Package 'combinat' is required but not installed")
  }

  # Set default output path if not provided
  if (is.null(output_file)) {
    output_dir <- dirname(file_path)
    output_file <- file.path(output_dir, "R_output.xlsx")
  }

  # 1. Read Excel data
  sheet1 <- readxl::read_excel(file_path, sheet = 1, col_names = TRUE, col_types = "text")
  sheet2 <- readxl::read_excel(file_path, sheet = 2, col_names = TRUE, col_types = "text")

  cat("Data reading completed\n")
  cat("Sheet1 dimensions:", dim(sheet1), "\n")
  cat("Sheet2 dimensions:", dim(sheet2), "\n")

  # Helper function: Parse x,y format strings to numeric matrix
  parse_pairs <- function(pair_strings) {
    if (length(pair_strings) == 0) {
      return(matrix(nrow = 0, ncol = 2))
    }

    pairs_matrix <- matrix(NA, nrow = length(pair_strings), ncol = 2)

    for (i in 1:length(pair_strings)) {
      if (is.na(pair_strings[i]) || pair_strings[i] == "" || pair_strings[i] == " " || pair_strings[i] == "NA") {
        pairs_matrix[i, 1] <- NA
        pairs_matrix[i, 2] <- NA
        next
      }

      clean_string <- gsub("[[:space:]]", "", pair_strings[i])

      if (!grepl(",", clean_string)) {
        found <- FALSE

        for (first_len in 1:2) {
          if (first_len < nchar(clean_string)) {
            first_part <- substr(clean_string, 1, first_len)
            second_part <- substr(clean_string, first_len + 1, nchar(clean_string))

            first_num <- suppressWarnings(as.numeric(first_part))
            second_num <- suppressWarnings(as.numeric(second_part))

            if (!is.na(first_num) && !is.na(second_num) &&
                first_num >= 1 && first_num <= 10 &&
                second_num >= 50 && second_num <= 120) {
              pairs_matrix[i, 1] <- first_num
              pairs_matrix[i, 2] <- second_num
              found <- TRUE
              break
            }
          }
        }

        if (!found) {
          if (grepl("\\.", clean_string)) {
            dot_pos <- regexpr("\\.", clean_string)[1]
            if (dot_pos > 1) {
              first_part <- substr(clean_string, 1, dot_pos + 1)
              second_part <- substr(clean_string, dot_pos + 2, nchar(clean_string))

              first_num <- suppressWarnings(as.numeric(first_part))
              second_num <- suppressWarnings(as.numeric(second_part))

              if (!is.na(first_num) && !is.na(second_num) &&
                  first_num >= 1 && first_num <= 10 &&
                  second_num >= 50 && second_num <= 120) {
                pairs_matrix[i, 1] <- first_num
                pairs_matrix[i, 2] <- second_num
                found <- TRUE
              }
            }
          }
        }

        if (!found) {
          pairs_matrix[i, 1] <- NA
          pairs_matrix[i, 2] <- NA
        }

      } else if (grepl(",", clean_string)) {
        numbers <- strsplit(clean_string, ",")[[1]]
        if (length(numbers) == 2) {
          num1 <- suppressWarnings(as.numeric(numbers[1]))
          num2 <- suppressWarnings(as.numeric(numbers[2]))

          if (!is.na(num1) && !is.na(num2)) {
            pairs_matrix[i, 1] <- num1
            pairs_matrix[i, 2] <- num2
          } else {
            pairs_matrix[i, 1] <- NA
            pairs_matrix[i, 2] <- NA
          }
        } else {
          pairs_matrix[i, 1] <- NA
          pairs_matrix[i, 2] <- NA
        }
      } else {
        pairs_matrix[i, 1] <- NA
        pairs_matrix[i, 2] <- NA
      }
    }

    return(pairs_matrix)
  }

  # Check for special conditions
  check_special_conditions <- function(n_pairs_sheet1, n_pairs_sheet2, pairs_sheet1) {
    condition1 <- n_pairs_sheet2 >= 5
    condition2 <- n_pairs_sheet2 == (n_pairs_sheet1 - 1)

    condition3 <- FALSE
    if (n_pairs_sheet1 >= 2) {
      last_two_second <- pairs_sheet1[(n_pairs_sheet1-1):n_pairs_sheet1, 2]
      condition3 <- abs(last_two_second[1] - last_two_second[2]) < 0.01
    }

    return(condition1 && condition2 && condition3)
  }

  # Data extraction function
  extract_data_pairs <- function(row_sheet1, row_sheet2) {
    pairs_str_sheet2 <- unlist(row_sheet2[-1])
    pairs_str_sheet1 <- unlist(row_sheet1[-1])

    valid_pairs_sheet2 <- pairs_str_sheet2[!is.na(pairs_str_sheet2) &
                                             pairs_str_sheet2 != "" &
                                             pairs_str_sheet2 != " " &
                                             pairs_str_sheet2 != "NA"]

    valid_pairs_sheet1 <- pairs_str_sheet1[!is.na(pairs_str_sheet1) &
                                             pairs_str_sheet1 != "" &
                                             pairs_str_sheet1 != " " &
                                             pairs_str_sheet1 != "NA"]

    n_pairs_sheet2 <- length(valid_pairs_sheet2)
    if (n_pairs_sheet2 == 0) {
      return(list(valid = FALSE, reason = "No pair data in Sheet2"))
    }

    parsed_all_sheet1 <- parse_pairs(valid_pairs_sheet1)
    parsed_sheet2 <- parse_pairs(valid_pairs_sheet2)

    is_special_case <- check_special_conditions(length(valid_pairs_sheet1), n_pairs_sheet2, parsed_all_sheet1)

    extraction_modes <- list()

    if (is_special_case) {
      mode1_pairs <- valid_pairs_sheet1[1:n_pairs_sheet2]
      extraction_modes[[1]] <- list(
        mode = "normal",
        pairs = mode1_pairs,
        description = "Normal sequential extraction"
      )

      if (length(valid_pairs_sheet1) >= n_pairs_sheet2 + 1) {
        mode2_pairs <- c(valid_pairs_sheet1[1:(n_pairs_sheet2-1)], valid_pairs_sheet1[n_pairs_sheet2+1])
        extraction_modes[[2]] <- list(
          mode = "skip_last",
          pairs = mode2_pairs,
          description = "Skip last and extract next pair"
        )
      }
    } else {
      if (length(valid_pairs_sheet1) < n_pairs_sheet2) {
        return(list(valid = FALSE, reason = paste("Insufficient non-empty pairs in Sheet1, need", n_pairs_sheet2, ", have", length(valid_pairs_sheet1))))
      }

      mode1_pairs <- valid_pairs_sheet1[1:n_pairs_sheet2]
      extraction_modes[[1]] <- list(
        mode = "normal",
        pairs = mode1_pairs,
        description = "Normal sequential extraction"
      )
    }

    results <- list()
    for (mode_idx in 1:length(extraction_modes)) {
      mode_info <- extraction_modes[[mode_idx]]

      parsed_pairs_sheet1 <- parse_pairs(mode_info$pairs)

      if (any(is.na(parsed_pairs_sheet1)) || any(is.na(parsed_sheet2))) {
        results[[mode_info$mode]] <- list(
          valid = FALSE,
          reason = "Pair parsing failed, invalid format exists"
        )
      } else {
        results[[mode_info$mode]] <- list(
          valid = TRUE,
          pairs_sheet1 = parsed_pairs_sheet1,
          description = mode_info$description
        )
      }
    }

    return(list(
      valid = TRUE,
      extraction_modes = results,
      pairs_sheet2 = parsed_sheet2,
      n_pairs = n_pairs_sheet2,
      is_special_case = is_special_case
    ))
  }

  # Calibration processing function
  calibration_processing <- function(pairs_sheet1, pairs_sheet2) {
    mean_diff_first <- mean(pairs_sheet1[, 1]) - mean(pairs_sheet2[, 1])
    mean_diff_second <- mean(pairs_sheet1[, 2]) - mean(pairs_sheet2[, 2])

    calibrated_pairs_s1 <- pairs_sheet1
    calibrated_pairs_s1[, 1] <- calibrated_pairs_s1[, 1] - mean_diff_first
    calibrated_pairs_s1[, 2] <- calibrated_pairs_s1[, 2] - mean_diff_second

    return(list(
      calibrated_pairs_s1 = calibrated_pairs_s1,
      calibration_info = list(
        first = list(
          applied = TRUE,
          value = mean_diff_first,
          reason = paste("First number correction:", round(mean_diff_first, 4))
        ),
        second = list(
          applied = TRUE,
          value = mean_diff_second,
          reason = paste("Second number correction:", round(mean_diff_second, 4))
        )
      )
    ))
  }

  # Helper function: Calculate pair RMSE
  calculate_pair_rmse <- function(pairs_s1, pairs_s2, range_first, range_second) {
    n_pairs <- nrow(pairs_s1)
    sum_squared <- 0

    for (i in 1:n_pairs) {
      diff_first <- (pairs_s1[i, 1] - pairs_s2[i, 1]) / range_first
      diff_second <- (pairs_s1[i, 2] - pairs_s2[i, 2]) / range_second
      sum_squared <- sum_squared + diff_first^2 + diff_second^2
    }

    rmse <- sqrt(sum_squared / (2 * n_pairs))
    return(rmse)
  }

  # Pair combination and RMSE calculation function
  calculate_all_rmse_for_matching <- function(calibrated_pairs_s1, pairs_sheet2) {
    n_pairs <- nrow(calibrated_pairs_s1)

    range_first <- max(pairs_sheet2[, 1]) - min(pairs_sheet2[, 1])
    range_second <- max(pairs_sheet2[, 2]) - min(pairs_sheet2[, 2])

    if (range_first == 0) range_first <- 1
    if (range_second == 0) range_second <- 1

    if (n_pairs <= 2) {
      total_rmse <- calculate_pair_rmse(calibrated_pairs_s1, pairs_sheet2, range_first, range_second)

      return(list(
        best_matching = list(
          pairs = cbind(calibrated_pairs_s1, pairs_sheet2),
          rmse = total_rmse,
          permutation = 1:n_pairs
        ),
        all_matchings = list(
          list(
            pairs = cbind(calibrated_pairs_s1, pairs_sheet2),
            rmse = total_rmse,
            permutation = 1:n_pairs
          )
        )
      ))
    }

    fixed_s1 <- calibrated_pairs_s1[1:2, , drop = FALSE]
    fixed_s2 <- pairs_sheet2[1:2, , drop = FALSE]

    remaining_s1 <- calibrated_pairs_s1[3:n_pairs, , drop = FALSE]
    remaining_s2 <- pairs_sheet2[3:n_pairs, , drop = FALSE]

    permutations <- combinat::permn(1:nrow(remaining_s2))

    all_matchings <- list()
    best_rmse <- Inf
    best_matching <- NULL

    for (perm_idx in 1:length(permutations)) {
      perm <- permutations[[perm_idx]]
      current_s2_remaining <- remaining_s2[perm, , drop = FALSE]
      current_s2 <- rbind(fixed_s2, current_s2_remaining)
      current_s1 <- rbind(fixed_s1, remaining_s1)

      current_rmse <- calculate_pair_rmse(current_s1, current_s2, range_first, range_second)

      full_permutation <- c(1:2, perm + 2)

      matching_result <- list(
        pairs = cbind(current_s1, current_s2),
        rmse = current_rmse,
        permutation = full_permutation
      )

      all_matchings[[perm_idx]] <- matching_result

      if (current_rmse < best_rmse) {
        best_rmse = current_rmse
        best_matching <- matching_result
      }
    }

    return(list(
      best_matching = best_matching,
      all_matchings = all_matchings
    ))
  }

  # Main processing function
  main_processing <- function(sheet1, sheet2) {
    results <- list()

    for (i in 1:nrow(sheet2)) {
      if (is.na(sheet2[[1]][i]) || sheet2[[1]][i] == "" || sheet2[[1]][i] == "Residues") {
        cat("Skipping Sheet2 row", i, ": Empty or title row\n")
        next
      }

      row_results <- list()

      for (j in 1:nrow(sheet1)) {
        if (is.na(sheet1[[1]][j]) || sheet1[[1]][j] == "" || sheet1[[1]][j] == "Residues") {
          next
        }

        extraction <- extract_data_pairs(sheet1[j, ], sheet2[i, ])

        if (!extraction$valid) {
          row_results[[as.character(j)]] <- list(
            valid = FALSE,
            reason = extraction$reason,
            rmse = NA,
            all_rmses = NA
          )
          next
        }

        best_overall_rmse <- Inf
        best_overall_matching <- NULL
        best_mode_name <- ""
        all_mode_results <- list()

        for (mode_name in names(extraction$extraction_modes)) {
          mode_result <- extraction$extraction_modes[[mode_name]]

          if (!mode_result$valid) {
            next
          }

          calibration_result <- calibration_processing(
            mode_result$pairs_sheet1,
            extraction$pairs_sheet2
          )

          matching_results <- calculate_all_rmse_for_matching(
            calibration_result$calibrated_pairs_s1,
            extraction$pairs_sheet2
          )

          best_rmse <- matching_results$best_matching$rmse

          mode_final_result <- list(
            rmse = best_rmse,
            all_rmses = sapply(matching_results$all_matchings, function(x) x$rmse),
            calibration_info = calibration_result$calibration_info,
            best_matching_pairs = matching_results$best_matching$pairs,
            all_matchings = matching_results$all_matchings,
            extraction_mode = mode_name,
            extraction_description = mode_result$description
          )

          all_mode_results[[mode_name]] <- mode_final_result

          if (best_rmse < best_overall_rmse) {
            best_overall_rmse <- best_rmse
            best_overall_matching <- mode_final_result
            best_mode_name <- mode_name
          }
        }

        if (!is.null(best_overall_matching)) {
          row_results[[as.character(j)]] <- list(
            valid = TRUE,
            rmse = best_overall_rmse,
            all_rmses = best_overall_matching$all_rmses,
            calibration_info = best_overall_matching$calibration_info,
            best_matching_pairs = best_overall_matching$best_matching_pairs,
            all_matchings = best_overall_matching$all_matchings,
            n_pairs = extraction$n_pairs,
            sheet1_row = j,
            extraction_mode = best_mode_name,
            extraction_description = best_overall_matching$extraction_description,
            all_mode_results = all_mode_results,
            is_special_case = extraction$is_special_case
          )
        } else {
          row_results[[as.character(j)]] <- list(
            valid = FALSE,
            reason = "All extraction modes invalid",
            rmse = NA,
            all_rmses = NA
          )
        }
      }

      results[[as.character(i)]] <- list(
        sheet2_row = i,
        all_results = row_results
      )
    }

    return(results)
  }

  # Execute main program
  cat("Starting data processing...\n")
  final_results <- main_processing(sheet1, sheet2)

  # Create simplified output data frame
  create_simplified_output <- function(final_results, sheet1, sheet2) {
    sheet1_with_rmse <- sheet1
    sheet1_with_rmse <- cbind(Sheet1_Row = 1:nrow(sheet1), sheet1_with_rmse)

    for (i in names(final_results)) {
      sheet2_row <- final_results[[i]]$sheet2_row
      sheet2_name <- sheet2[[1]][sheet2_row]

      best_rmse_col_name <- paste0("Best_RMSE_", sheet2_name)
      sheet1_with_rmse[[best_rmse_col_name]] <- NA

      for (j in names(final_results[[i]]$all_results)) {
        comp <- final_results[[i]]$all_results[[j]]
        if (comp$valid) {
          sheet1_row <- as.numeric(j)
          sheet1_with_rmse[[best_rmse_col_name]][sheet1_row] <- comp$rmse
        }
      }
    }

    sheet2_matching_details <- list()

    for (i in names(final_results)) {
      sheet2_row <- final_results[[i]]$sheet2_row
      sheet2_name <- sheet2[[1]][sheet2_row]

      matching_details_list <- list()

      for (j in names(final_results[[i]]$all_results)) {
        comp <- final_results[[i]]$all_results[[j]]

        if (comp$valid) {
          sheet1_row <- as.numeric(j)
          sheet1_name <- sheet1[[1]][sheet1_row]

          best_matching_pairs <- comp$best_matching_pairs
          best_pair_sequence <- ""

          if (!is.null(best_matching_pairs) && nrow(best_matching_pairs) > 0) {
            pair_strings <- sapply(1:nrow(best_matching_pairs), function(k) {
              s1_x <- round(best_matching_pairs[k, 1], 3)
              s1_y <- round(best_matching_pairs[k, 2], 3)
              s2_x <- round(best_matching_pairs[k, 3], 3)
              s2_y <- round(best_matching_pairs[k, 4], 3)
              paste0("(", s1_x, ",", s1_y, ")↔(", s2_x, ",", s2_y, ")")
            })
            best_pair_sequence <- paste(pair_strings, collapse = " | ")
          }

          matching_details_list[[length(matching_details_list) + 1]] <- data.frame(
            Sheet1_Row = sheet1_row,
            Sheet1_Name = sheet1_name,
            Best_RMSE = comp$rmse,
            Num_Pairs = comp$n_pairs,
            Extraction_Mode = comp$extraction_mode,
            Extraction_Description = comp$extraction_description,
            Is_Special_Case = comp$is_special_case,
            Best_Matching_Sequence = best_pair_sequence,
            Calibration_First = comp$calibration_info$first$reason,
            Calibration_Second = comp$calibration_info$second$reason,
            stringsAsFactors = FALSE
          )
        }
      }

      if (length(matching_details_list) > 0) {
        sheet2_matching_details[[sheet2_name]] <- do.call(rbind, matching_details_list)
      } else {
        sheet2_matching_details[[sheet2_name]] <- data.frame(
          Sheet1_Row = integer(),
          Sheet1_Name = character(),
          Best_RMSE = numeric(),
          Num_Pairs = integer(),
          Extraction_Mode = character(),
          Extraction_Description = character(),
          Is_Special_Case = logical(),
          Best_Matching_Sequence = character(),
          Calibration_First = character(),
          Calibration_Second = character(),
          stringsAsFactors = FALSE
        )
      }
    }

    return(list(
      sheet1_with_rmse = sheet1_with_rmse,
      sheet2_matching_details = sheet2_matching_details
    ))
  }

  # Save results to Excel
  cat("Creating output data...\n")
  simplified_output <- create_simplified_output(final_results, sheet1, sheet2)

  output_dir <- dirname(output_file)
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }

  cat("Saving results to Excel...\n")
  cat("Output file:", output_file, "\n")

  wb <- openxlsx::createWorkbook()

  openxlsx::addWorksheet(wb, "Sheet1_With_RMSE")
  openxlsx::writeData(wb, "Sheet1_With_RMSE", simplified_output$sheet1_with_rmse)

  for (sheet2_name in names(simplified_output$sheet2_matching_details)) {
    sheet_name <- paste0("BestMatch_", sheet2_name)
    sheet_name <- gsub("[\\/:*?\"<>|]", "", sheet_name)
    if (nchar(sheet_name) > 31) {
      sheet_name <- substr(sheet_name, 1, 31)
    }

    openxlsx::addWorksheet(wb, sheet_name)
    openxlsx::writeData(wb, sheet_name, simplified_output$sheet2_matching_details[[sheet2_name]])
  }

  openxlsx::saveWorkbook(wb, output_file, overwrite = TRUE)

  # Return results
  cat("\nProcessing completed\n")
  cat("Results saved to:", output_file, "\n")

  return(list(
    results = final_results,
    simplified_output = simplified_output,
    output_file = output_file
  ))
}
